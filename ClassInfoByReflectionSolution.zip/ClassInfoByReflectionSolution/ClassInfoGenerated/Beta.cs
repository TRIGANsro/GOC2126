﻿namespace ClassInfoGenerated;

public class Beta
{
    [MyInfo(ExtraInfo = "This is a property in Beta")]
    public int MyProperty { get; set; }
}