﻿namespace ClassInfoGenerated;

public class Gama
{
    
}