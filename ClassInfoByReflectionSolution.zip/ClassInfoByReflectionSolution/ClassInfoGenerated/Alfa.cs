﻿namespace ClassInfoGenerated;

public class Alfa
{
    
}