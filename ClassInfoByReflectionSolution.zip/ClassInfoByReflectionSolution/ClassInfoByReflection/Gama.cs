﻿namespace ClassInfoByReflection;

public class Gama
{
    
}