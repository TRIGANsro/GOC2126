﻿namespace ClassInfoByReflection;

public class Alfa
{
    
}